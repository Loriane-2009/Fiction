<template>
  <router-view />
</template>

<script setup>
// rien ici
</script>
